#!/bin/bash

clear
cp -r razx /bin/
cp -r razxeffect /bin/
cp -r razxsettings /bin/